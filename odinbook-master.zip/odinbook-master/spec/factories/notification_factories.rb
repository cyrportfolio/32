FactoryGirl.define do 
  factory :notification do 
    message "Lorem ipsum"
    user
  end
end
