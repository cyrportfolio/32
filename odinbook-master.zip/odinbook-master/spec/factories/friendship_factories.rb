FactoryGirl.define do
  factory :friendship do
    friender
    friended
    accepted true
  end
end
